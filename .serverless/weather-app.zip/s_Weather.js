
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'choowder1',
  applicationName: 'weather-app',
  appUid: 'BCJRPyXw55gywfrhvd',
  orgUid: '73c5kph6hNx3jNFtZ8',
  deploymentUid: '3ca4dfcc-630d-4ade-a7ef-68b3edac74b2',
  serviceName: 'weather-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'weather-app-dev-Weather', timeout: 6 };

try {
  const userHandler = require('./Service/function.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getWeather, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}